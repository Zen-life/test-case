//Pull newly entered comments to the Latest comment field
//then clears the comment and other form fields ready for next comment
//cms codes

var myStars = []; //for the rating
let cname, email, comm, rate;

function showComm() {    
    comm = document.getElementById("comment");
    cname = document.getElementById("name");
    email = document.getElementById("email");
    rate = document.getElementById("rating");
    if(comm.value != " " || comm.value == null) {
    document.getElementById("ltcomment").value +=  comm.value + "\n" + "Rated: " + rate.value + " Stars "  + "\n" + "By: " + cname.value + " " + email.value + "\n\n";
    document.getElementById("comment").value = "";
    document.getElementById("name").value = "";
    document.getElementById("email").value = "";
     }
   };


// check star rating and aggregate
    var star1 = 0;  var star2 = 0; var star3 = 0;  var star4 = 0;  var star5 = 0;

   function rateCheck() {
      let curRate = Number(rate.value.trim());
    
    //switching to check comment rating and update relevant array for the chart
    switch (curRate) {
        case 1:
            star1 += 1; //if rating is 1 star add one and update relevant index
            var str1 = star1;           
            myStars[0] = str1;                        
            chart.data.datasets[0].data = myStars;  //updated chart with new array data
            chart.update(); // and reload                      
            break;
        case 2:
            star2 += 1; 
            var str2 = star2;            
            myStars[1] = str2;                 
            chart.data.datasets[0].data = myStars;  //reload chart with updated array data    
            chart.update();                      
            break;
        case 3:
            star3 += 1;
            var str3 = star3;            
            myStars[2] = str3; 
             
            chart.data.datasets[0].data = myStars; //reload chart with updated array data
            chart.update();                   
            break;
        case 4:
            star4 += 1;
            var str4 = star4;            
            myStars[3] = str4;            
            chart.data.datasets[0].data = myStars; //reload chart with updated array data
            chart.update();
            break;
        case 5:    
            star5 += 1;
            var str5 = star5;            
            myStars[4] = str5;                       
            chart.data.datasets[0].data = myStars;  //reload chart with updated array data
            chart.update();  
        } //end switch
    };  //cms codes End

    //chart codes start
    var ctx = document.getElementById('myChart').getContext('2d');
    var chart = new Chart(ctx, {
    // type of chart to create
    type: 'bar',

    // data for chart  dataset
    data: {
        labels: ["1 Star", "2 stars", "3 Stars", "4 Stars", "5 Stars"],
        datasets: [{
            label: "Comments",
            backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(255, 99, 132)',
            data: myStars,
            backgroundColor: [
                'rgba(255, 99, 132, 0.8)',
                'rgba(54, 162, 235, 0.8)',
                'rgba(255, 206, 86, 0.8)',
                'rgba(75, 192, 192, 0.8)',
                'rgba(153, 102, 255, 0.8)'
            ],
            
        }]
    },

    // chart options 
    options: {
        title: {
            display: true,
            text: 'Comment Ratings',
            fontColor: '#666',
            fontSize: 22,
            position: 'top'
        },
        scales: {
            yAxes: [{
              ticks: {
                  beginAtZero: true
              }
            }]
        },
        legend: {
            display: true,            
            text: ["1 Star", "2 stars", "3 Stars", "4 Stars", "5 Stars"],
            labels: {
                fontColor: 'rgb(255, 99, 132)'
            }
        }

     }  // options end

}); //chart codes End