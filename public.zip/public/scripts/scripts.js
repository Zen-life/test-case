//"Use strict"

//Pull newly entered comments to the Latest comment field
//then clears the comment box ready for next comment
function showcomm() {
    let cname, email, comm, rate;
    comm = document.getElementById("comment");
    cname = document.getElementById("name");
    email = document.getElementById("email");
    rate = document.getElementById("rating");
    if(comm.value != " " || comm.value == null) {
    document.getElementById("ltcomment").value =  comm.value + "\n" + "Rated: " + rate.value + " Stars "  + "\n" + "By: " + cname.value + " " + email.value + "\n";
     document.getElementById("comment").value = "";
     document.getElementById("name").value = "";
     document.getElementById("email").value = "";
    }
   }
   
   // Pulls latest comment and added it to previous comments in a hidden field
   // console log to show data pulled to hidden field.
   function archivePost() {
    let ltcom;
    ltcom = document.getElementById("ltcomment");
    if(ltcom.value != " " || ltcom.value == null) {
     document.getElementById("pastcomms").value += ltcom.value + "\n\n";
    console.log(document.getElementById("pastcomms").value);
    }
   }